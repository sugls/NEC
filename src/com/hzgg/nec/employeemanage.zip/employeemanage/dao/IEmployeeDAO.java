/**
 * 
 */
package com.hzgg.nec.employeemanage.dao;

import com.hzgg.nec.employeemanage.po.Employee;
import com.hzgg.nec.employeemanage.po.Userinfo;

/**
 * @author Mr.H
 *
 * create date  2017��3��1��  ����11:04:47
 */
public interface IEmployeeDAO {
	/**

	 * @return Employee
	 */
	Employee checkLogin(Userinfo user);

	Userinfo selectUserByEmpId(int employeeid);

	Employee selectEmployeeById(int employeeid);
}

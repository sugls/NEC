/**
 * 
 */
package com.hzgg.nec.employeemanage.dao;

import org.apache.ibatis.session.SqlSession;

import com.hzgg.nec.employeemanage.po.Employee;
import com.hzgg.nec.employeemanage.po.Userinfo;
import com.hzgg.nec.util.MybatisSqlSessionFactory;

/**
 * @author Mr.H
 *
 * create date  2017??3??1??  ????11:05:28
 */
public class EmployeeDAOImpl implements IEmployeeDAO {

	/**
	 * 
	 */
	public EmployeeDAOImpl() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public Employee checkLogin(Userinfo user) {
		// TODO Auto-generated method stub
		Employee emp = null;	
		SqlSession session = MybatisSqlSessionFactory.getSqlSession();
		Userinfo u = session.selectOne("checklogin",user);
		if (u != null){
			emp = session.selectOne("getEmployeeById",u.getEmployeeid());
		}
		MybatisSqlSessionFactory.closeSqlSession();
		return emp;
	}

	@Override
	public Userinfo selectUserByEmpId(int employeeid) {
		Userinfo user = null;
		SqlSession session = MybatisSqlSessionFactory.getSqlSession();
		user = session.selectOne("selectUserByEmployeeId",employeeid);
		MybatisSqlSessionFactory.closeSqlSession();
		return user;
	}

	public Employee selectEmployeeById(int employeeid){
		Employee emp = null;
		SqlSession session = MybatisSqlSessionFactory.getSqlSession();
		emp = session.selectOne("getEmployeeById",employeeid);
		MybatisSqlSessionFactory.closeSqlSession();
		return emp;
	}
}
